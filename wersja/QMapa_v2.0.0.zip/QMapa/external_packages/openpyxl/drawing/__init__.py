# Copyright (c) 2010-2022 openpyxl


from .drawing import Drawing
